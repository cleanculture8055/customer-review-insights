from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

# Simple Insight Generation (based on keywords)
def generate_insight(review):
    review_lower = review.lower()
    if any(word in review_lower for word in ["love", "great", "excellent", "amazing"]):
        return "Praise", "Highlight in marketing"
    elif any(word in review_lower for word in ["slow", "drain", "problem", "bad"]):
        return "Problem", "Consider improving feature"
    else:
        return "Neutral", "No immediate action"

@app.route("/", methods=["GET", "POST"])
def index():
    conn = sqlite3.connect('reviews.db')
    c = conn.cursor()

    if request.method == "POST":
        # Add new review
        new_review = request.form['review_text']
        category, insight = generate_insight(new_review)
        c.execute('INSERT INTO reviews (review_text, category, insight) VALUES (?, ?, ?)',
                  (new_review, category, insight))
        conn.commit()
        conn.close()
        return redirect(url_for('index'))

    # Fetch all reviews
    c.execute('SELECT review_text, category, insight FROM reviews')
    reviews = c.fetchall()
    conn.close()
    return render_template("index.html", reviews=reviews)

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)