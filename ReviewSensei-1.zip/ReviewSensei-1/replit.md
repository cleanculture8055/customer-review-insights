# Customer Review Insights Prototype

## Overview

This is a simple customer review analysis web application that automatically categorizes customer reviews and generates actionable business insights. The system allows users to submit reviews through a web interface and uses keyword-based analysis to classify reviews as Praise, Problem, or Neutral, providing corresponding business recommendations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The application uses a traditional server-side rendered web interface built with Flask's templating system. The frontend consists of:
- **Templates**: Jinja2 templates for HTML rendering with dynamic content
- **Static Assets**: CSS styling for basic visual presentation
- **Form Handling**: Simple HTML forms for review submission

### Backend Architecture
The backend follows a monolithic Flask application pattern:
- **Web Framework**: Flask handles HTTP requests, routing, and template rendering
- **Business Logic**: Simple keyword-based sentiment analysis for review categorization
- **Data Processing**: Automatic insight generation based on review content analysis

### Data Storage
The application uses SQLite as its primary data store:
- **Database**: Single SQLite file (`reviews.db`) for simplicity and portability
- **Schema**: Single `reviews` table with columns for ID, review text, category, and insights
- **Data Access**: Direct SQL queries using Python's sqlite3 module

### Review Analysis System
The core feature implements a basic natural language processing approach:
- **Categorization Logic**: Keyword matching against predefined positive and negative word lists
- **Insight Generation**: Business recommendations mapped to review categories
- **Categories**: Three-tier classification system (Praise, Problem, Neutral)

## External Dependencies

### Python Packages
- **Flask**: Web framework for handling HTTP requests and responses
- **sqlite3**: Built-in Python module for database operations (no external dependency)

### Database
- **SQLite**: Embedded database requiring no separate server installation
- **Storage**: Local file-based storage system

### Frontend Dependencies
- **No external frameworks**: Uses vanilla HTML/CSS with Flask's built-in templating
- **Styling**: Custom CSS without external libraries like Bootstrap or jQuery

### Development Tools
- **Database Setup**: Standalone script (`setup_db.py`) for initial database creation and sample data population
- **Sample Data**: Predefined review examples for testing and demonstration purposes